# DAProject2022
pip install -r requirements.txt
